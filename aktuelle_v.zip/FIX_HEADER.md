Fix. v0.62: P Module kompakt und hausintern formuliert (kurz, handlungsorientiert, einheitlicher Stil, Patient*innen Schreibweise).
Fix. v0.60: CTEPD ohne PH Logik ergänzt (Kriterien Check in V/Q Bereich + konservative Regelwerk Bewertung ohne stille Annahmen).
Fix. v0.59: Stufenoxymetrie Handschrift Box: Reihenfolge PA RV RA SVC und alle Schreiblinien sind vollständig sichtbar.
